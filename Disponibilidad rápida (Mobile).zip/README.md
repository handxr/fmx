
  # Disponibilidad rápida (Mobile)

  This is a code bundle for Disponibilidad rápida (Mobile). The original project is available at https://www.figma.com/design/EWdUCWcgsLTQW5kINZ0pGM/Disponibilidad-r%C3%A1pida--Mobile-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  