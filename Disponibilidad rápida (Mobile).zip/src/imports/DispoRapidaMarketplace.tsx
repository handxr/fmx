import svgPaths from "./svg-a74ekvkv4f";

function Informacion() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Informacion">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Informacion">
          <path d={svgPaths.p1a2c2770} fill="var(--fill-0, #098AC3)" id="Path" />
        </g>
      </svg>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Montserrat:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333] text-[16px] w-full">
        <p className="css-4hzbpn leading-[24px]">Sin disponibilidad este día</p>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[16px] items-start justify-center min-h-px min-w-px relative">
      <Frame2 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[8px] items-start relative shrink-0 w-full">
      <Informacion />
      <Frame />
    </div>
  );
}

function Borde() {
  return (
    <div className="absolute inset-0 rounded-[8px]" data-name="Borde">
      <div aria-hidden="true" className="absolute border border-[#098ac3] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Alert() {
  return (
    <div className="bg-[#f2fafd] relative rounded-[8px] shrink-0 w-full" data-name="Alert">
      <div className="content-stretch flex flex-col gap-[8px] items-start p-[16px] relative w-full">
        <Frame1 />
        <Borde />
      </div>
    </div>
  );
}

function DiaDispoRapida() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="dia-dispo-rapida">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:Medium',sans-serif] gap-[4px] items-center not-italic px-[4px] py-[8px] relative text-center w-full">
          <p className="css-4hzbpn h-[14px] leading-[16px] relative shrink-0 text-[#8c8c8c] text-[12px] w-[34px]">J</p>
          <div className="flex flex-col h-[14px] justify-center leading-[0] relative shrink-0 text-[#333] text-[16px] w-[36px]">
            <p className="css-4hzbpn leading-[24px]">12</p>
          </div>
          <p className="css-4hzbpn leading-[14px] relative shrink-0 text-[#333] text-[14px] w-[36px]">nov</p>
        </div>
      </div>
    </div>
  );
}

function DiaDispoRapida1() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="dia-dispo-rapida">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:Medium',sans-serif] gap-[4px] items-center not-italic px-[4px] py-[8px] relative text-center w-full">
          <p className="css-4hzbpn h-[14px] leading-[16px] relative shrink-0 text-[#8c8c8c] text-[12px] w-[34px]">V</p>
          <div className="flex flex-col h-[14px] justify-center leading-[0] relative shrink-0 text-[#333] text-[16px] w-[36px]">
            <p className="css-4hzbpn leading-[24px]">13</p>
          </div>
          <p className="css-4hzbpn leading-[14px] relative shrink-0 text-[#333] text-[14px] w-[36px]">nov</p>
        </div>
      </div>
    </div>
  );
}

function DiaDispoRapida2() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="dia-dispo-rapida">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:Medium',sans-serif] gap-[4px] items-center not-italic px-[4px] py-[8px] relative text-center w-full">
          <p className="css-4hzbpn h-[14px] leading-[16px] relative shrink-0 text-[#8c8c8c] text-[12px] w-[34px]">S</p>
          <div className="flex flex-col h-[14px] justify-center leading-[0] relative shrink-0 text-[#333] text-[16px] w-[36px]">
            <p className="css-4hzbpn leading-[24px]">14</p>
          </div>
          <p className="css-4hzbpn leading-[14px] relative shrink-0 text-[#333] text-[14px] w-[36px]">nov</p>
        </div>
      </div>
    </div>
  );
}

function DiaDispoRapida3() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="dia-dispo-rapida">
      <div aria-hidden="true" className="absolute border-2 border-[#8c8c8c] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col gap-[4px] items-center not-italic px-[4px] py-[8px] relative text-[#333] text-center w-full">
          <p className="css-4hzbpn font-['Montserrat:Medium',sans-serif] h-[14px] leading-[16px] relative shrink-0 text-[12px] w-[34px]">D</p>
          <div className="flex flex-col font-['Montserrat:Bold',sans-serif] h-[14px] justify-center leading-[0] relative shrink-0 text-[16px] w-[36px]">
            <p className="css-4hzbpn leading-[24px]">15</p>
          </div>
          <p className="css-4hzbpn font-['Montserrat:Medium',sans-serif] leading-[14px] relative shrink-0 text-[14px] w-[36px]">nov</p>
        </div>
      </div>
    </div>
  );
}

function DiaDispoRapida4() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[8px]" data-name="dia-dispo-rapida">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col font-['Montserrat:Medium',sans-serif] gap-[4px] items-center not-italic px-[4px] py-[8px] relative text-center w-full">
          <p className="css-4hzbpn h-[14px] leading-[16px] relative shrink-0 text-[#8c8c8c] text-[12px] w-[34px]">L</p>
          <div className="flex flex-col h-[14px] justify-center leading-[0] relative shrink-0 text-[#333] text-[16px] w-[36px]">
            <p className="css-4hzbpn leading-[24px]">16</p>
          </div>
          <p className="css-4hzbpn leading-[14px] relative shrink-0 text-[#333] text-[14px] w-[36px]">nov</p>
        </div>
      </div>
    </div>
  );
}

function CalendarIcon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Calendar icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Calendar icon">
          <path d={svgPaths.pe0d58b0} fill="var(--fill-0, #333333)" fillOpacity="0.9" id="path" />
        </g>
      </svg>
    </div>
  );
}

function MoreDatesContainer() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[4px] self-stretch" data-name="More dates container">
      <div aria-hidden="true" className="absolute border border-[#ccc] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-col items-center justify-center size-full">
        <div className="content-stretch flex flex-col gap-[4px] items-center justify-center p-[4px] relative size-full">
          <CalendarIcon />
          <div className="font-['Montserrat:Medium',sans-serif] leading-[16px] min-w-full not-italic relative shrink-0 text-[#333] text-[12px] text-center w-[min-content]">
            <p className="css-4hzbpn mb-0">{`Más `}</p>
            <p className="css-4hzbpn">fechas</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DateContainer() {
  return (
    <div className="content-stretch flex gap-[8px] items-start relative shrink-0 w-full" data-name="Date container">
      <DiaDispoRapida />
      <DiaDispoRapida1 />
      <DiaDispoRapida2 />
      <DiaDispoRapida3 />
      <DiaDispoRapida4 />
      <MoreDatesContainer />
    </div>
  );
}

function DateSelection() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Date selection">
      <DateContainer />
    </div>
  );
}

function DateSelection1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Date selection">
      <DateSelection />
    </div>
  );
}

function GroupPriceTextContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[2px] items-center leading-[0] not-italic px-[8px] relative shrink-0 tracking-[-0.32px] w-[114px]" data-name="Group price text container">
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Light',sans-serif] justify-center relative shrink-0 text-[#666] text-[12px]">
        <p className="css-ew64yg leading-[1.3]">Desde</p>
      </div>
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Bold',sans-serif] justify-center relative shrink-0 text-[#333] text-[16px] text-center">
        <p className="css-ew64yg leading-[1.1]">50,40 €</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#ea0558] flex-[1_0_0] h-[48px] min-h-px min-w-px relative rounded-[1000px]" data-name="Button">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex gap-[16px] items-center justify-center px-[24px] py-[16px] relative size-full">
          <p className="css-ew64yg font-['Montserrat:Medium',sans-serif] leading-[24px] not-italic relative shrink-0 text-[18px] text-center text-white">Otras actividades</p>
        </div>
      </div>
    </div>
  );
}

function OptionsButtonContainer() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-end min-h-px min-w-px relative" data-name="Options button container">
      <Button />
    </div>
  );
}

function GroupPriceContainer() {
  return (
    <div className="bg-white content-stretch flex items-center justify-between py-[8px] relative shrink-0 w-full" data-name="Group price container">
      <GroupPriceTextContainer />
      <OptionsButtonContainer />
    </div>
  );
}

function ReservationInfoIcon() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Reservation info icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Reservation info icon">
          <path d={svgPaths.p3961e580} fill="var(--fill-0, #C2044B)" id="path" />
        </g>
      </svg>
    </div>
  );
}

function ReservationInfoIconContainer() {
  return (
    <div className="bg-[#ffeaf1] content-stretch flex items-center p-[4px] relative rounded-[100px] shrink-0" data-name="Reservation info icon container">
      <ReservationInfoIcon />
    </div>
  );
}

function Cancelacion() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="Cancelacion">
      <ReservationInfoIconContainer />
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333] text-[14px]">
        <p className="css-ew64yg leading-[20px]">64 reservas en las últimas 24 horas</p>
      </div>
    </div>
  );
}

function CancellationInfoIcon() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Cancellation info icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Cancellation info icon">
          <g id="path">
            <path d={svgPaths.p2697f700} fill="var(--fill-0, #00825B)" />
            <path d={svgPaths.p12023a40} fill="var(--fill-0, #00825B)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function CancellationInfoIconContainer() {
  return (
    <div className="bg-[#dafaeb] content-stretch flex items-center p-[4px] relative rounded-[100px] shrink-0" data-name="Cancellation info icon container">
      <CancellationInfoIcon />
    </div>
  );
}

function Cancelacion1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="Cancelacion">
      <CancellationInfoIconContainer />
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333] text-[14px]">
        <p className="css-ew64yg leading-[20px]">Cancela gratis hasta 24 horas antes</p>
      </div>
    </div>
  );
}

function ReservationInfoContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Reservation info container">
      <Cancelacion />
      <Cancelacion1 />
    </div>
  );
}

export default function DispoRapidaMarketplace() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[16px] items-start justify-center p-[16px] relative rounded-[8px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] size-full" data-name="Dispo rápida Marketplace">
      <Alert />
      <DateSelection1 />
      <GroupPriceContainer />
      <ReservationInfoContainer />
    </div>
  );
}