export default function DiaDispoRapida() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[4px] items-center px-[4px] py-[8px] relative rounded-[8px] size-full" data-name="dia-dispo-rapida">
      <div aria-hidden="true" className="absolute border-2 border-[#8c8c8c] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="css-4hzbpn font-['Montserrat:Medium',sans-serif] h-[14px] leading-[16px] not-italic relative shrink-0 text-[#333] text-[12px] text-center w-[34px]">V</p>
      <div className="flex flex-col font-['Montserrat:Bold',sans-serif] h-[14px] justify-center leading-[0] not-italic relative shrink-0 text-[#333] text-[16px] text-center w-[36px]">
        <p className="css-4hzbpn leading-[24px]">13</p>
      </div>
      <p className="css-4hzbpn font-['Montserrat:Medium',sans-serif] leading-[14px] not-italic relative shrink-0 text-[#333] text-[14px] text-center w-[36px]">nov</p>
    </div>
  );
}