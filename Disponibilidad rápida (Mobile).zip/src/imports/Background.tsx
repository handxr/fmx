export default function Background() {
  return (
    <div className="bg-[#ea0558] content-stretch flex items-start justify-center relative rounded-[23.91px] size-full" data-name="Background">
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16.9px] text-center text-white tracking-[-0.32px]">
        <p className="css-ew64yg leading-[47.81px]">15</p>
      </div>
    </div>
  );
}