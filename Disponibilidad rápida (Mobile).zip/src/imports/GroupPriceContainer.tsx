export function GroupPriceContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[2px] items-center leading-[0] not-italic px-[8px] relative shrink-0 tracking-[-0.32px] w-[114px]" data-name="Group price text container">
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Light',sans-serif] justify-center relative shrink-0 text-[#666] text-[12px]">
        <p className="css-ew64yg leading-[1.3]">Desde</p>
      </div>
      <div className="css-g0mm18 flex flex-col font-['Montserrat:Bold',sans-serif] justify-center relative shrink-0 text-[#333] text-[16px] text-center">
        <p className="css-ew64yg leading-[1.1]">50,40 €</p>
      </div>
    </div>
  );
}